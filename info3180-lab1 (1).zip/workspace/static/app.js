console.log('Hello, my JavaScript file has loaded');
